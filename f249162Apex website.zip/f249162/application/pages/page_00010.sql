prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>23477370237969702084
,p_default_application_id=>249162
,p_default_id_offset=>0
,p_default_owner=>'WKSP_M0BILEAPP'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'makina layout'
,p_alias=>'MAKINA-LAYOUT'
,p_step_title=>'makina layout'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Header{',
'    display: none;',
'}',
'.t-Footer{',
'      display: none;',
'}',
'',
'/* ----------------           ----------------------- */',
'@import url(''https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400&display=swap'');',
'',
':root{',
'    --purple:#0092BE;',
'    --pink:#76BCBC;',
'    --gradient:linear-gradient(90deg, var(--purple), var(--pink));',
'}',
'',
'*{',
'    font-family: ''Poppins'', sans-serif;',
'    margin:0; padding:0;',
'    box-sizing: border-box;',
'    text-decoration: none;',
'    outline: none; border:none;',
'    text-transform: capitalize;',
'}',
'',
'*::selection{',
'    background:var(--pink);',
'    color:#fff;',
'}',
'',
'html{',
'    font-size: 62.5%;',
'    overflow-x: hidden;',
'}',
'',
'body{',
'    background:#f9f9f9;',
'}',
'',
'.section{',
'    min-height: 100vh;',
'    padding:0 9%;',
'    padding-top: 7.5rem;',
'    padding-bottom: 2rem;',
'}',
'',
'.btn{',
'    display: inline-block;',
'    margin-top: 1rem;',
'    padding:.8rem 3rem;',
'    border-radius: 5rem;',
'    background:var(--gradient);',
'    font-size: 1.7rem;',
'    color:#fff;',
'    cursor: pointer;',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    transition: all .3s linear;',
'}',
'',
'.btn:hover{',
'    transform: scale(1.1);',
'}',
'',
'',
'/*--------------Menu Bar -------------------*/',
'',
'.heading{',
'    text-align: center;',
'    background:var(--gradient);',
'    color:transparent;',
'    -webkit-background-clip: text;',
'    background-clip: text;',
'    font-size: 3.5rem;',
'    text-transform: uppercase;',
'    padding:1rem;',
'}',
'',
'header{',
'    position: fixed;',
'    top:0; left:0;',
'    width:100%;',
'    background:#fff;',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    padding:2rem 9%;',
'    display: flex;',
'    align-items: center;',
'    justify-content: space-between;',
'    z-index: 1000;',
'}',
'',
'header .logo{',
'    font-size: 2rem;',
'    color:var(--purple);',
'}',
'',
'header .logo span{',
'    color:var(--pink);',
'}',
'',
'header .navbar a{',
'    font-size: 1.7rem;',
'    margin-left: 2rem;',
'    color:var(--purple);',
'}',
'',
'header .navbar a:hover{',
'    color:var(--pink);',
'}',
'',
'header input{',
'    display: none;',
'}',
'',
'header label{',
'    font-size: 3rem;',
'    color:var(--purple);',
'    cursor: pointer;',
'    visibility: hidden;',
'    opacity: 0;',
'}',
'/*---------Home----------*/',
'.home{',
'   display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    background:url(#APP_FILES#home-bg-img.png) no-repeat;',
'    background-size: cover;',
'    background-position: center;',
'}',
'',
'.home .image img{',
'    width:40vw;',
'    animation: float 3s linear infinite;',
'}',
'',
'@keyframes float{',
'    0%, 100%{',
'        transform: translateY(0rem);',
'    }',
'    50%{',
'        transform: translateY(-3.5rem);',
'    }',
'}',
'',
'',
'.home .content h3{',
'    font-size: 5.5rem;',
'    color:#333;',
'    text-transform: uppercase;',
'}',
'',
'.home .content h3 span{',
'    color:var(--pink);',
'    text-transform: uppercase;',
'}',
'',
'.home .content p{',
'    font-size: 1.7rem;',
'    color:#666;',
'    padding:1rem 0;',
'}',
'',
'#B59088117390154017049{  /*home dowenload btn*/',
'',
'  ',
'}',
'',
'/* --------------------Feture Card-----------------------*/',
'',
'.features .box-container{',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-wrap: inherit;',
'}',
'.center-btn{   /*feture btn read more*/',
'',
'    margin-left: 57px;',
'',
'}',
'.features .box-container .box{',
'    flex:1 1 30rem;',
'    background:#fff;',
'    border-radius: .5rem;',
'    border:.1rem solid rgba(0,0,0,.2);',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    margin:1.5rem;',
'    padding:3rem 2rem;',
'    border-radius: .5rem;',
'    text-align: center;',
'    transition: .2s linear;',
'}',
'',
'.features .box-container .box img{',
'    height: 15rem;',
'}',
'',
'.features .box-container .box .crd-h3{',
'    font-size: 2rem;',
'    color:#333;',
'    padding-top: 1rem;',
'}',
'',
'.features .box-container .box .p-car{',
'    font-size: 1.3rem;',
'    color:#666;',
'    padding: 1rem 0;',
'    line-height: 1.5;',
'',
'}',
'',
'/*--------------------About----------------------------------*/',
'.about{',
'    background:url(#APP_FILES#about-bg.png) no-repeat;',
'    background-size: cover;',
'    background-position: center;',
'    padding-bottom: 3rem;',
'}',
'',
'.about .column{',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-wrap: wrap;',
'}',
'',
'.about .column .image{',
'    flex:1 1 40rem;',
'}',
'',
'.about .column .image img{',
'    width:100%;',
'}',
'',
'.about .column .content{',
'    flex:1 1 40rem;',
'}',
'',
'.about .column .content h3{',
'    font-size: 3rem;',
'    color:#666;',
'}',
'',
'.about .column .content p{',
'    font-size: 1.5rem;',
'    color:#666;',
'    padding:1rem 0;',
'}',
'',
'.about .column .content .buttons a:last-child{',
'    margin-left: 2rem;',
'}',
'',
'/*----------------newsletter--------------------------------*/',
'.newsletter{',
'    text-align: center;',
'    padding:5rem 1rem;',
'    background:url(#APP_FILES#subscribe-bg.png) no-repeat;',
'    background-size: cover;',
'    background-position: center;',
'}',
'',
'.newsletter h3{',
'    color:#fff;',
'    font-size: 3rem;',
'    text-transform: uppercase;',
'}',
'',
'.newsletter p{',
'    color:#fff;',
'    font-size: 1.6rem;',
'    margin:2rem auto;',
'    width:70rem;',
'}',
'',
'#P4_EMAIL_NAME{',
'',
'    font-size: 1.7rem;',
'  width: 100%;',
'  color: #fff;',
'  background: none;',
'  max-width: 70rem;',
'  border: .2rem solid #fff;',
'  padding: .5rem;',
'  border-radius: 5rem;',
'  margin: 2rem auto;',
'  height: 5.5rem;',
'}',
'#P4_EMAIL_NAME ::placeholder{',
'     color:#eee;',
'    text-transform: capitalize;',
'    margin-left: 10px; ',
'}',
'',
'',
'#B59577396587080376346{  /* subscribe btn */',
'background:#fff;',
'    width:18rem;',
'    font-size: 1.7rem;',
'    border-radius: 5rem;',
'    cursor: pointer;',
'    height: 4.2rem;',
'    bottom: 73px;',
'  left: 250px;',
'}',
'',
'#B59577396587080376346:hover{',
'        color:var(--pink);',
'',
'',
'}',
'',
'/*----------------END    newsletter--------------------------------*/',
'',
'',
'',
'/*----------------------review -------------------*/',
'',
'.review .box-container{',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-wrap: inherit;',
'',
'}',
'',
'.review .box-container .box{',
'    background:#fff;',
'    margin:1rem;',
'    padding:1rem;',
'    text-align: center;',
'    position: relative;',
'    border:.1rem solid rgba(0,0,0,.2);',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    flex:1 1 30rem;',
'    border-radius: .5rem;',
'}',
'',
'.review .box-container .box .fa-quote-right{',
'    position: absolute;',
'    top:1rem; right:7rem;',
'    font-size: 8rem;',
'    color:var(--pink);',
'    opacity: .3;',
'}',
'',
'.review .box-container .box .user img{',
'    border-radius: 50%;',
'    object-fit: cover;',
'    height: 7rem;',
'    width:7rem;',
'    margin-top: 2rem;',
'}',
'',
'',
'',
'.titl-rev{',
'',
'    color:var(--pink);',
'    font-size: 2rem;',
'}',
'',
'.review .box-container .box .user .stars i{',
'    color:var(--purple);',
'    font-size: 1.5rem;',
'    padding:1rem 0;',
'}',
'',
'.review .box-container .box .comment{',
'    color:#666;',
'    font-size: 1.4rem;',
'    padding:1rem;',
'    line-height: 1.5;',
'}',
'/*----------------------review end-------------------*/',
'',
'/*---------------------- Pricing start -------------------*/',
'',
'',
'',
'.pricing .box-container{',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-wrap: wrap;',
'}',
'',
'.pricing .box-container .box{',
'    flex:1 1 27rem;',
'    margin:1rem;',
'    padding:1rem;',
'    background:#fff;',
'    border:.1rem solid rgba(0,0,0,.2);',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    border-radius: .5rem;',
'    text-align: center;',
'    padding-bottom: 3rem;',
'}',
'',
'.pricing .box-container .box:nth-child(2),',
'.pricing .box-container .box:hover{',
'    border:.2rem solid var(--pink);',
'}',
'',
'.pricing .box-container .box .title{',
'    color:var(--purple);',
'    font-size: 2.5rem;',
'    padding-top: 1rem;',
'}',
'',
'.pricing .box-container .box .price{',
'    font-size: 4rem;',
'    color:var(--pink);',
'    padding:1rem 0;',
'}',
'',
'.pricing .box-container .box .price span{',
'    font-size: 2rem;',
'}',
'',
'.pricing .box-container .box ul{',
'    padding:1rem 0;',
'    list-style: none;',
'}',
'',
'.pricing .box-container .box ul li{',
'    font-size: 1.7rem;',
'    color:#666;',
'    padding:.5rem 0;',
'}',
'',
'.pricing .box-container .box ul li .fa-check{',
'    color:lightgreen;',
'}',
'',
'.pricing .box-container .box ul li .fa-times{',
'    color:tomato;',
'}',
'',
'.pric-btn{',
'',
'    margin-left: 4rem;',
'    height: 3rem;',
'}',
'',
'/*---------------------- Pricing end -------------------*/',
'',
'',
'.contact{',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-wrap: wrap;',
'    padding-bottom: 4rem;',
'}',
'',
'.contact .image{',
'    flex:1 1 40rem;',
'}',
'',
'.contact .image img{',
'    width:100%;',
'    padding:2rem;',
'}',
'',
'.contact form{',
'    flex:1 1 40rem;',
'    padding:2rem 3rem;',
'    border:.1rem solid rgba(0,0,0,.2);',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    border-radius: .5rem;',
'    background:#fff;',
'}',
'',
'.contact form .heading{',
'    text-align: left;',
'    padding:0;',
'    padding-bottom: 2rem;',
'}',
'',
'.contact form .inputBox{',
'    position: relative;',
'}',
'',
'.contact form .inputBox input, .contact form .inputBox textarea{',
'    width:100%;',
'    background:none;',
'    color:#666;',
'    margin:1.5rem 0;',
'    padding:.5rem 0;',
'    font-size: 1.7rem;',
'    border-bottom: .1rem solid rgba(0,0,0,.1);',
'    text-transform: none;',
'}',
'',
'.contact form .inputBox textarea{',
'    resize: none;',
'    height: 13rem;',
'}',
'',
'.contact form .inputBox label{',
'    position: absolute;',
'    top:1.7rem; left:0;',
'    font-size: 1.7rem;',
'    color:#666;',
'    transition: .2s linear;',
'}',
'',
'.contact form .inputBox input:focus ~ label,',
'.contact form .inputBox input:valid ~ label,',
'.contact form .inputBox textarea:focus ~ label,',
'.contact form .inputBox textarea:valid ~ label{',
'    top:-.5rem;',
'    font-size: 1.5rem;',
'    color:var(--pink);',
'}',
'',
'/*---------------------- Contact end -------------------*/',
'',
'',
'/*---------------------- Contact start -------------------*/',
'',
'',
'.contact{',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-wrap: wrap;',
'    padding-bottom: 4rem;',
'}',
'',
'.contact .image{',
'    flex:1 1 40rem;',
'}',
'',
'.contact .image img{',
'    width:100%;',
'    padding:2rem;',
'}',
'/* ',
'.contact .contact-form{',
'    flex:1 1 40rem;',
'    padding:2rem 3rem;',
'    border:.1rem solid rgba(0,0,0,.2);',
'    box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'    border-radius: .5rem;',
'    background:#fff;',
'} */',
'',
'/* .contact .contact-form .heading{',
'    text-align: left;',
'    padding:0;',
'    padding-bottom: 2rem;',
'}',
'',
'.contact .contact-form .inputBox{',
'    position: relative;',
'}',
'',
'.contact .contact-form .inputBox input, .contact .contact-form .inputBox textarea{',
'    width:100%;',
'    background:none;',
'    color:#666;',
'    margin:1.5rem 0;',
'    padding:.5rem 0;',
'    font-size: 1.7rem;',
'    border-bottom: .1rem solid rgba(0,0,0,.1);',
'    text-transform: none;',
'}',
'',
'.contact .contact-form .inputBox textarea{',
'    resize: none;',
'    height: 13rem;',
'}',
'',
'.contact .contact-form .inputBox label{',
'    position: absolute;',
'    top:1.7rem; left:0;',
'    font-size: 1.7rem;',
'    color:#666;',
'    transition: .2s linear;',
'}',
'',
'.contact .contact-form .inputBox input:focus ~ label,',
'.contact  .contact-form .inputBox input:valid ~ label,',
'.contact  .contact-form .inputBox textarea:focus ~ label,',
'.contact  .contact-form .inputBox textarea:valid ~ label{',
'    top:-.5rem;',
'    font-size: 1.5rem;',
'    color:var(--pink);',
'} */',
'',
'',
'',
'',
'',
'',
'/*---------------------- Footer start -------------------*/',
'',
'',
'',
'.footer{',
'    padding-top: 3rem;',
'    background:url(#APP_FILES#footer-bg.png) no-repeat;',
'    background-size: cover;',
'    background-position: center;',
'}',
'',
'.footer .box-container{',
'    display: flex;',
'    flex-wrap: wrap;',
'}',
'',
'.footer .box-container .box{',
'    flex:1 1 25rem;',
'    margin:2rem;',
'}',
'',
'.footer .box-container .box h3{',
'    font-size: 2.5rem;',
'    padding:1rem 0;',
'    color:#fff;',
'    text-decoration: underline;',
'    text-underline-offset: 1rem;',
'}',
'',
'.footer .box-container .box p{',
'    font-size: 1.5rem;',
'    padding:.5rem 0;',
'    color:#eee;',
'}',
'',
'.footer .box-container .box a{',
'    display: block;',
'    font-size: 1.5rem;',
'    padding:.5rem 0;',
'    color:#eee;',
'}',
'',
'.footer .box-container .box a:hover{',
'    text-decoration: underline;',
'}',
'',
'.footer .box-container .box .info{',
'    display: flex;',
'    align-items: center;',
'}',
'',
'.footer .box-container .box .info i{',
'    margin:.5rem 0;',
'    margin-right: 1rem;',
'    border-radius: 50%;',
'    background:#fff;',
'    color:var(--pink);',
'    font-size: 1.5rem;',
'    height:4.5rem;',
'    width:4.5rem;',
'    line-height: 4.5rem;',
'    text-align: center;',
'}',
'',
'.footer .credit{',
'    font-size: 2rem;',
'    font-weight: normal;',
'    letter-spacing: .1rem;',
'    color:#fff;',
'    border-top: .1rem solid #fff5;',
'    padding:2.5rem 1rem;',
'    text-align: center;',
'}',
'',
'.footer .credit a{',
'    font-size: 2rem;',
'    font-weight: normal;',
'    letter-spacing: .1rem;',
'    color:#fff;',
'    border-top: .1rem solid #fff5;',
'    padding:2.5rem 1rem;',
'    text-align: center;',
'}',
'',
'.footer .credit a:hover{',
'    font-size: 2rem;',
'    font-weight: normal;',
'    letter-spacing: .1rem;',
'    color:#fff;',
'    border-top: .1rem solid #fff5;',
'    padding:2.5rem 1rem;',
'    text-align: center;',
'    background-color: black;',
'    padding: 5px;',
'    border-radius: 5px;',
'    border: 2px solid #fff;',
'}',
'',
'',
'/*---------------------- Footer end -------------------*/',
'',
'',
'/* -------media queries  ------------*/',
'',
'@media (max-width:1200px){',
'    ',
'    html{',
'        font-size: 55%;',
'    }',
'',
'}',
'',
'@media (max-width:991px){',
'    ',
'    section{',
'        padding:0 3%;',
'        padding-top: 7.5rem;',
'        padding-bottom: 2rem;',
'    }',
'',
'}',
'',
'@media (max-width:768px){',
'',
'    header label{',
'        visibility: visible;',
'        opacity: 1;',
'    }',
'',
'    header .navbar{',
'        position: absolute;',
'        top:100%; left: 0;',
'        width:100%;',
'        background:#fff;',
'        padding:1rem 2rem;',
'        border-top: .1rem solid rgba(0,0,0,.2);',
'        box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);',
'        transform-origin: top;',
'        transform: scaleY(0);',
'        opacity: 0;',
'        transition: .2s linear;',
'    }',
'',
'    header .navbar a{',
'        display: block;',
'        margin:2rem 0;',
'        font-size: 2rem;',
'    }',
'',
'    header input:checked ~ .navbar{',
'        transform: scaleY(1);',
'        opacity: 1;',
'    }',
'',
'    header input:checked ~ label::before{',
'        content:''\f00d'';',
'    }',
'',
'    .home{',
'        flex-flow: column-reverse;',
'    }',
'',
'    .home .image img{',
'        width:100%;',
'    }',
'',
'    .home .content h3{',
'        font-size: 3.6rem;',
'    }',
'',
'    .home .content p{',
'        font-size: 1.5rem;',
'    }',
'',
'    .about{',
'        background-position: right;',
'    }',
'',
'    .newsletter p{',
'        width:auto;',
'    }',
'',
'}',
'',
'@media (max-width:450px){',
'    ',
'    html{',
'        font-size: 50%;',
'    }',
'',
'    .about .column .content .buttons a{',
'        width:100%;',
'        text-align: center;',
'    }',
'',
'    .about .column .content .buttons a:last-child{',
'        margin: 1rem 0;',
'    }',
'',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590912785077254048)
,p_plug_name=>'Home section'
,p_region_name=>'home'
,p_region_css_classes=>'section home'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590912937014254049)
,p_plug_name=>'content'
,p_parent_plug_id=>wwv_flow_imp.id(120590912785077254048)
,p_region_css_classes=>'content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' <h3>best mobile app <span>showcase</span></h3>',
'<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus suscipit porro nam libero natus error consequatur sed repudiandae eos quo?</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590913294964254053)
,p_plug_name=>'button'
,p_parent_plug_id=>wwv_flow_imp.id(120590912937014254049)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590913878352254059)
,p_plug_name=>'image'
,p_parent_plug_id=>wwv_flow_imp.id(120590912785077254048)
,p_region_css_classes=>'image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#home-img.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590913049799254051)
,p_plug_name=>'header'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<header>',
'',
'    <a href="#" class="logo"><span>best</span>App</a>',
'',
'    <input type="checkbox" id="menu-bar">',
'    <label for="menu-bar" class="fas fa-bars"></label>',
'',
'    <nav class="navbar">',
'        <a href="#home">home</a>',
'        <a href="#features">features</a>',
'        <a href="#about">about</a>',
'        <a href="#review">review</a>',
'        <a href="#pricing">pricing</a>',
'        <a href="#contact">contact</a>',
'    </nav>',
'',
'</header>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590913459032254055)
,p_plug_name=>'features section'
,p_region_name=>'features'
,p_region_css_classes=>'section features'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590913642295254056)
,p_plug_name=>'heading'
,p_parent_plug_id=>wwv_flow_imp.id(120590913459032254055)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'<h1 class="heading"> app features </h1>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590913684281254057)
,p_plug_name=>'Fetures card'
,p_parent_plug_id=>wwv_flow_imp.id(120590913459032254055)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'FEATURES'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(61502818073099237048)
,p_region_id=>wwv_flow_imp.id(120590913684281254057)
,p_layout_type=>'GRID'
,p_component_css_classes=>'box-container'
,p_card_css_classes=>'box'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_title_css_classes=>'crd-h3'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPE'
,p_body_css_classes=>'p-car'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#f-icon1.png'
,p_media_display_position=>'FIRST'
,p_media_sizing=>'FIT'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(61502818500050237048)
,p_card_id=>wwv_flow_imp.id(61502818073099237048)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'read more'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'btn center-btn'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590914039299254060)
,p_plug_name=>'about section'
,p_region_name=>'about'
,p_region_css_classes=>'section about'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590914107731254061)
,p_plug_name=>'heading'
,p_parent_plug_id=>wwv_flow_imp.id(120590914039299254060)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'   <h1 class="heading"> about the app </h1>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080193477293613360)
,p_plug_name=>'column'
,p_parent_plug_id=>wwv_flow_imp.id(120590914039299254060)
,p_region_css_classes=>'column'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590914213829254062)
,p_plug_name=>'image'
,p_parent_plug_id=>wwv_flow_imp.id(121080193477293613360)
,p_region_css_classes=>'image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#about-img.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590914316815254063)
,p_plug_name=>'content'
,p_parent_plug_id=>wwv_flow_imp.id(121080193477293613360)
,p_region_css_classes=>'content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Easy And Perfect Solution For Your Business App</h3>',
'            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nulla placeat deserunt saepe repudiandae veniam soluta minima dolor hic aperiam iure.</p>',
'            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium, quaerat. Dolorem ratione saepe magni quo inventore porro ab voluptates eos, nam eius provident accusantium, quia similique est, repellendus et reiciendis.</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080193639752613361)
,p_plug_name=>'buttons'
,p_parent_plug_id=>wwv_flow_imp.id(120590914316815254063)
,p_region_css_classes=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120590914920496254069)
,p_plug_name=>'newsletter'
,p_region_css_classes=>'newsletter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>70
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080189485738613320)
,p_plug_name=>'text'
,p_parent_plug_id=>wwv_flow_imp.id(120590914920496254069)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Subscribe For New Features</h3>',
'    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus sed aliquam quibusdam neque magni magnam est laborum doloribus, facere dolores.</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080189610267613321)
,p_plug_name=>'News-form'
,p_parent_plug_id=>wwv_flow_imp.id(120590914920496254069)
,p_region_css_classes=>'formaaa'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'MAJOR'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080190177984613327)
,p_plug_name=>'review section'
,p_region_name=>'review'
,p_region_css_classes=>'section review'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>80
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080190249927613328)
,p_plug_name=>'heading'
,p_parent_plug_id=>wwv_flow_imp.id(121080190177984613327)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    <h1 class="heading"> people''s review </h1>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080190407939613329)
,p_plug_name=>'reviw'
,p_parent_plug_id=>wwv_flow_imp.id(121080190177984613327)
,p_region_css_classes=>'review'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'FEATURES'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(61502808612992237038)
,p_region_id=>wwv_flow_imp.id(121080190407939613329)
,p_layout_type=>'GRID'
,p_component_css_classes=>'box-container'
,p_card_css_classes=>'box'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_title_css_classes=>'titl-rev'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="comment">',
'    &DESCRIPE.',
'                </div>'))
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fas fa-quote-right'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'#APP_FILES#pic1.png'
,p_media_display_position=>'FIRST'
,p_media_sizing=>'FIT'
,p_media_css_classes=>'user'
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080190552396613331)
,p_plug_name=>'pricing section'
,p_region_name=>'pricing'
,p_region_css_classes=>'section pricing'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>90
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080190702239613332)
,p_plug_name=>'heading'
,p_parent_plug_id=>wwv_flow_imp.id(121080190552396613331)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    <h1 class="heading"> Our Pricing Plans </h1>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080190903359613334)
,p_plug_name=>'Pricing'
,p_parent_plug_id=>wwv_flow_imp.id(121080190552396613331)
,p_region_css_classes=>'pricing'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'PRICING'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(61502803516285237032)
,p_region_id=>wwv_flow_imp.id(121080190903359613334)
,p_layout_type=>'GRID'
,p_component_css_classes=>'box-container'
,p_card_css_classes=>'box'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_title_css_classes=>'title'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            <div class="price">&PRICE.<span>/monthly</span></div>',
''))
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'                <li> <i class="fas fa-check"></i> 1000+ downloads </li>',
'                <li> <i class="fas fa-check"></i> No transaction fees </li>',
'                <li> <i class="fas fa-times"></i> unlimited storage </li>',
'                <li> <i class="fas fa-times"></i> 5 downloads </li>',
'            </ul>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(61502804029676237033)
,p_card_id=>wwv_flow_imp.id(61502803516285237032)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'check out'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'btn pric-btn'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080191229505613337)
,p_plug_name=>'contact section'
,p_region_name=>'contact'
,p_region_css_classes=>'section contact'
,p_region_template_options=>'#DEFAULT#:js-headingLevel-2:t-Form--labelsAbove'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>100
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080191322230613338)
,p_plug_name=>'image'
,p_parent_plug_id=>wwv_flow_imp.id(121080191229505613337)
,p_region_css_classes=>'image'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#contact-img.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080191409333613339)
,p_plug_name=>'contact us'
,p_parent_plug_id=>wwv_flow_imp.id(121080191229505613337)
,p_region_css_classes=>'contact-form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'STUDENTS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080192874901613354)
,p_plug_name=>'footer section'
,p_region_css_classes=>'footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>120
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121363952999064112624)
,p_plug_name=>'box-container'
,p_parent_plug_id=>wwv_flow_imp.id(121080192874901613354)
,p_region_css_classes=>'box-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080193009179613355)
,p_plug_name=>'about us'
,p_parent_plug_id=>wwv_flow_imp.id(121363952999064112624)
,p_region_css_classes=>'box'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>about us</h3>',
'            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet pariatur rerum consectetur architecto ad tempora blanditiis quo aliquid inventore a.</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080193119497613356)
,p_plug_name=>'quick links'
,p_parent_plug_id=>wwv_flow_imp.id(121363952999064112624)
,p_region_css_classes=>'box'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' <h3>quick links</h3>',
'            <a href="#">home</a>',
'            <a href="#">features</a>',
'            <a href="#">about</a>',
'            <a href="#">review</a>',
'            <a href="#">pricing</a>',
'            <a href="#">contact</a>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080193244031613357)
,p_plug_name=>'follow us'
,p_parent_plug_id=>wwv_flow_imp.id(121363952999064112624)
,p_region_css_classes=>'box'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            <h3>follow us</h3>',
'<a href="https://www.facebook.com/FreeWebsiteCode/">facebook</a>',
'            <a href="https://twitter.com/freewebsitecode">twitter</a>',
'            <a href="https://www.youtube.com/FreeWebsiteCode/videos">youtube</a>',
'            <a href="https://www.linkedin.com/in/freewebsitecode/">linkedin</a>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121080193268704613358)
,p_plug_name=>'contact info '
,p_parent_plug_id=>wwv_flow_imp.id(121363952999064112624)
,p_region_css_classes=>'box'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'            <h3>contact info</h3>',
' <div class="info">',
'                <i class="fas fa-phone"></i>',
'                <p> +123-456-7890 <br> +111-2222-333 </p>',
'            </div>',
'            <div class="info">',
'                <i class="fas fa-envelope"></i>',
'                <p> example@gmail.com <br> example@gmail.com </p>',
'            </div>',
'            <div class="info">',
'                <i class="fas fa-map-marker-alt"></i>',
'                <p> City, Country - 1234 </p>',
'            </div>',
'        </div>',
'',
'    </div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121363953710543112631)
,p_plug_name=>'test'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>130
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61502811550783237041)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(121080193639752613361)
,p_button_name=>'App_store'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'   App Store'
,p_button_css_classes=>'btn fab fa-apple '
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61502811934576237041)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(121080193639752613361)
,p_button_name=>'google_play'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>' Google Play'
,p_button_css_classes=>'btn fab fa-google-play '
,p_grid_new_row=>'N'
,p_grid_column=>4
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61502813131596237042)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(121080189610267613321)
,p_button_name=>'subscripe'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Subscripe'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61502799299623237025)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_button_name=>'Send_Message'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send Message'
,p_button_css_classes=>'btn'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61502820734901237050)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(120590912937014254049)
,p_button_name=>'Dowenload'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Dowenload Now'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'btn'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121080193815170613348)
,p_name=>'P10_STU_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_item_source_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_source=>'STU_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121080193886669613349)
,p_name=>'P10_FULL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_item_source_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_prompt=>'Full Name'
,p_source=>'FULL_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_css_classes=>'inputBox'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121080193974130613350)
,p_name=>'P10_PHONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_item_source_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_prompt=>'Phone'
,p_source=>'PHONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>1609121967514267634
,p_item_css_classes=>'inputBox'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121080194113010613351)
,p_name=>'P10_E_MAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_item_source_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_prompt=>'E Mail'
,p_source=>'E_MAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_css_classes=>'inputBox'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121080205960848613347)
,p_name=>'P10_MAJOR_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(121080189610267613321)
,p_item_source_plug_id=>wwv_flow_imp.id(121080189610267613321)
,p_source=>'MAJOR_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121080205987682613348)
,p_name=>'P10_EMAIL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(121080189610267613321)
,p_item_source_plug_id=>wwv_flow_imp.id(121080189610267613321)
,p_placeholder=>'Enter Yout E-Mail'
,p_source=>'MAJOR_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_css_classes=>'news-mail'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'LEADING')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121363955286934112632)
,p_name=>'P10_DESC'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(121080191409333613339)
,p_prompt=>'Desc'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_css_classes=>'inputBox'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121363972271431112658)
,p_name=>'P10_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(121363953710543112631)
,p_placeholder=>'Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121363972398738112659)
,p_name=>'P10_NEW_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(121363953710543112631)
,p_placeholder=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121363972492910112660)
,p_name=>'P10_NEW_2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(121363953710543112631)
,p_placeholder=>'phone'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61502814862155237044)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(121080189610267613321)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form makina layout'
,p_internal_uid=>61502814862155237044
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61502802408205237029)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(121080191409333613339)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form makina layout contact'
,p_internal_uid=>61502802408205237029
);
wwv_flow_imp.component_end;
end;
/
