prompt --application/deployment/install/install_db_script
begin
--   Manifest
--     INSTALL: INSTALL-DB Script
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>23477370237969702084
,p_default_application_id=>249162
,p_default_id_offset=>0
,p_default_owner=>'WKSP_M0BILEAPP'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(61512112673514370281)
,p_install_id=>wwv_flow_imp.id(61505803452117327359)
,p_name=>'DB Script'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  CREATE TABLE "FEATURES" ',
'   (	"ID" NUMBER(*,0), ',
'	"NAME" VARCHAR2(60), ',
'	"DESCRIPE" VARCHAR2(500), ',
'	"IMG_URL" VARCHAR2(100)',
'   ) ;',
'',
'  CREATE TABLE "PRICING" ',
'   (	"ID" NUMBER(*,0), ',
'	"NAME" VARCHAR2(100), ',
'	"PRICE" NUMBER(*,0)',
'   ) ;',
'',
'  CREATE TABLE "STUDENTS" ',
'   (	"STU_ID" NUMBER(*,0), ',
'	"FULL_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"PHONE" VARCHAR2(50), ',
'	"E_MAIL" VARCHAR2(255), ',
'	"GENDER" VARCHAR2(10), ',
'	"STU_CODE" VARCHAR2(50), ',
'	"USER_ID" NUMBER(*,0), ',
'	"PATCH_NO" NUMBER(*,0), ',
'	"SECTION_ID" NUMBER(*,0), ',
'	"DEPT_ID" NUMBER(*,0), ',
'	"MAJOR_ID" NUMBER(*,0), ',
'	"ACADEMIC_YEAR_ID" NUMBER(*,0), ',
'	 PRIMARY KEY ("STU_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  ALTER TABLE "STUDENTS" ADD FOREIGN KEY ("USER_ID")',
'	  REFERENCES "USERS" ("USER_ID") ENABLE;',
'  ALTER TABLE "STUDENTS" ADD FOREIGN KEY ("SECTION_ID")',
'	  REFERENCES "SECTIONS" ("SECTION_ID") ENABLE;',
'  ALTER TABLE "STUDENTS" ADD FOREIGN KEY ("MAJOR_ID")',
'	  REFERENCES "MAJOR" ("MAJOR_ID") ENABLE;',
'  ALTER TABLE "STUDENTS" ADD FOREIGN KEY ("ACADEMIC_YEAR_ID")',
'	  REFERENCES "ACADEMIC_YEAR" ("ACAD_ID") ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "STUDENTS_TRIGGER" ',
'BEFORE INSERT ON Students ',
'FOR EACH ROW ',
'BEGIN ',
'    SELECT Students_seq.NEXTVAL INTO :NEW.Stu_id FROM DUAL; ',
'END;',
'/',
'ALTER TRIGGER "STUDENTS_TRIGGER" ENABLE;'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(61512112749815370282)
,p_script_id=>wwv_flow_imp.id(61512112673514370281)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FEATURES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(61512112998028370283)
,p_script_id=>wwv_flow_imp.id(61512112673514370281)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'PRICING'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(61512113189984370283)
,p_script_id=>wwv_flow_imp.id(61512112673514370281)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'STUDENTS'
);
wwv_flow_imp.component_end;
end;
/
