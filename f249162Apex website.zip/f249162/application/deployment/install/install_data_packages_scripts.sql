prompt --application/deployment/install/install_data_packages_scripts
begin
--   Manifest
--     INSTALL: INSTALL-Data Packages Scripts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>23477370237969702084
,p_default_application_id=>249162
,p_default_id_offset=>0
,p_default_owner=>'WKSP_M0BILEAPP'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(61512256792495377370)
,p_install_id=>wwv_flow_imp.id(61505803452117327359)
,p_name=>'Data Packages Scripts'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --FEATURES: 3/10000 rows exported, APEX$DATA$PKG/FEATURES$966354',
'    apex_data_install.load_supporting_object_data(p_table_name => ''FEATURES'', p_delete_after_install => true );',
'    --PRICING: 3/10000 rows exported, APEX$DATA$PKG/PRICING$291536',
'    apex_data_install.load_supporting_object_data(p_table_name => ''PRICING'', p_delete_after_install => true );',
'    --STUDENTS: 0/10000 rows exported, no file generated',
'    apex_data_install.load_supporting_object_data(p_table_name => ''STUDENTS'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
